<?php
// Spanish extension, https://github.com/annaesvensson/yellow-language/tree/main/translations/spanish

class YellowSpanish {
    const VERSION = "0.8.36";
    public $yellow;         // access to API
    
    // Handle initialisation
    public function onLoad($yellow) {
        $this->yellow = $yellow;
        $this->yellow->language->setDefault($this->getDefault());
    }
    
    // Handle update
    public function onUpdate($action) {
        $fileName = $this->yellow->system->get("coreExtensionDirectory").$this->yellow->system->get("coreSystemFile");
        if ($action=="install") {
            $this->yellow->system->save($fileName, array("language" => "es"));
        } elseif ($action=="uninstall" && $this->yellow->system->get("language")=="es") {
            $this->yellow->system->save($fileName, array("language" => $this->yellow->system->getDifferent("language")));
        }
    }
    
    // Return default language settings
    public function getDefault() {
        return <<< 'END'
        Language: es
        LanguageLocale: es_ES
        LanguageDescription: Español
        LanguageTranslator: Al Garcia, David Garcia
        BerlinDescription: Berlin is a theme inspired by Dieter Rams.
        BlogDescription: Blog for your website.
        BlogBy: por
        BlogTag: Etiquetas:
        BlogMore: Leer más…
        BreadcrumbDescription: Breadcrumb navigation.
        BreadcrumbNavigation: Breadcrumb
        BundleDescription: Bundle website files.
        ChineseDescription: Chinese/简体中文 with language 'zh'.
        CommandDescription: Command line of the website.
        ContactDescription: Email contact page.
        ContactName: Nombre:
        ContactEmail: Email:
        ContactMessage: Mensaje:
        ContactConsent: Doy mi consentimiento para que este sitio web almacene mi mensaje.
        ContactButton: Enviar mi mensaje
        ContactMailSpam: [Spam]
        ContactMailHeader: You have received a message from @sender:
        ContactMailFooter: This email was sent via @sitename - @title
        ContactStatusNone: Di hola. Tus comentarios son bien recibidos.
        ContactStatusIncomplete: Por favor llena todos los campos.
        ContactStatusInvalid: Por favor introduce una dirección de email válida.
        ContactStatusReview: Please remove links from the message.
        ContactStatusDone: Enviaste un email. ¡Gracias!
        ContactStatusError: El email no pudo ser enviado, por favor intenta más tarde.
        CopenhagenDescription: Copenhagen is a beautiful theme.
        CoreDescription: Funcionalidad principal del sitio web.
        CoreNavigation: Main
        CorePagination: Page
        CorePaginationPrevious: ← Anterior
        CorePaginationNext: Siguiente →
        CoreTimeFormatShort: H:i
        CoreTimeFormatMedium: H:i:s
        CoreTimeFormatLong: H:i:s T
        CoreDateFormatShort: F Y
        CoreDateFormatMedium: d-m-Y
        CoreDateFormatLong: d-m-Y H:i
        CoreDatePast: today, yesterday, @x days ago, 1 month ago, @x months ago, 1 year ago, @x years ago, on @x
        CoreDateFuture: soon, tomorrow, in @x days, in 1 month, in @x months, in 1 year, in @x years, on @x
        CoreDateMonthsNominative: Enero, Febrero, Marzo, Abril, Mayo, Junio, Julio, Agosto, Septiembre, Octubre, Noviembre, Diciembre
        CoreDateMonthsGenitive: Enero, Febrero, Marzo, Abril, Mayo, Junio, Julio, Agosto, Septiembre, Octubre, Noviembre, Diciembre
        CoreDateWeekdays: Lunes, Martes, Miércoles, Jueves, Viernes, Sábado, Domingo
        CoreDateWeekstart: Lunes
        CoreDecimalSeparator: ,
        CoreError404Title: Archivo no encontrado
        CoreError404Text: El archivo solicitado no fue encontrado. Oh no...
        CoreError420Title: Page not public
        CoreError420Text: The requested page is not public. [yellow error]
        CoreError430Title: Login failed
        CoreError430Text: The email or password is incorrect. [Please try again](#data-action-login).
        CoreError434Title: Page not found
        CoreError434Text: The requested page was not found. [You can create this page](#data-action-edit).
        CoreError435Title: Page not found
        CoreError435Text: The requested page has been deleted. [You can restore this page](#data-action-restore).
        CoreError450Title: Update error
        CoreError450Text: Can't connect to the update server. An Internet connection is required.
        CoreError500Title: Server error
        CoreError500Text: Something went wrong. [yellow error]
        CzechDescription: Czech/Čeština with language 'cs'.
        DanishDescription: Danish/Dansk with language 'da'.
        DisqusDescription: Show Disqus comments on blog.
        DraftDescription: Support for draft pages.
        DraftPageError: Please log in.
        DutchDescription: Dutch/Nederlands with language 'nl'.
        EditDescription: Edite su sitio web en un navegador web.
        EditLoginTitle: Bienvenido
        EditLoginEmail: Email:
        EditLoginPassword: Contraseña:
        EditLoginForgot: ¿Olvidaste tu contraseña?
        EditLoginSignup: ¿Crear una cuenta de usuario?
        EditLoginButton: Acceder
        EditSignupTitle: Crear una cuenta de usuario
        EditSignupName: Nombre:
        EditSignupEmail: Email:
        EditSignupPassword: Contraseña:
        EditSignupConsent: Doy mi consentimiento para que este sitio web almacene mis datos personales.
        EditSignupButton: Crear
        EditSignupStatusNone: Aquí podrás crear una nueva cuenta de usuario.
        EditSignupStatusIncomplete: Por favor llena todos los campos.
        EditSignupStatusInvalid: Por favor introduce una dirección de email válida.
        EditSignupStatusWeak: Por favor introduce una contraseña distinta.
        EditSignupStatusShort: Por favor introduce una contraseña más larga.
        EditSignupStatusNext: La cuenta de usuario será creada, por favor revisa tu email.
        EditForgotTitle: Olvidaste tu contraseña
        EditForgotEmail: Email:
        EditForgotStatusNone: No hay problema, puedes crear una nueva contraseña.
        EditForgotStatusInvalid: Por favor introduce una dirección de email válida.
        EditForgotStatusNext: La cuenta de usuario será recuperada, por favor revisa tu email.
        EditRecoverTitle: Olvidaste tu contraseña
        EditRecoverPassword: Contraseña:
        EditRecoverStatusPassword: Por favor introduce una nueva contraseña.
        EditRecoverStatusWeak: Por favor introduce una contraseña distinta.
        EditRecoverStatusShort: Por favor introduce una contraseña más larga.
        EditRecoverStatusDone: Cuenta de usuario recuperada. ¡Gracias!
        EditConfirmSubject: Confirmar cuenta de usuario
        EditConfirmMessage: Hola @usershort,\n\npor favor confirma tu cuenta. Haz click en el siguiente enlace.
        EditConfirmTitle: Cuenta de usuario
        EditConfirmStatusDone: Cuenta de usuario confirmada y espera la aprobación. ¡Gracias!
        EditApproveSubject: Aprobar cuenta de usuario
        EditApproveMessage: Hola @usershort,\n\npor favor aprueba la nueva cuenta para @useraccount. Haz click en el siguiente enlace.
        EditApproveTitle: Cuenta de usuario
        EditApproveStatusDone: Cuenta de usuario aprobada. ¡Gracias!
        EditReactivateSubject: Reactivate user account
        EditReactivateMessage: Hi @usershort,\n\nplease reactivate your user account. There were too many failed login attempts. Click the following link.
        EditReactivateTitle: Cuenta de usuario
        EditReactivateStatusDone: User account reactivated. Thank you!
        EditVerifySubject: Change user account
        EditVerifyMessage: Hi @usershort,\n\nplease confirm a new email for your user account. Click the following link.
        EditVerifyTitle: Cuenta de usuario
        EditVerifyStatusDone: User account changed. Thank you!
        EditChangeSubject: Change user account
        EditChangeMessage: Hi @usershort,\n\nplease confirm that you want to change your user account. Click the following link.
        EditChangeTitle: Cuenta de usuario
        EditChangeStatusDone: User account changed. Thank you!
        EditRemoveSubject: Delete user account
        EditRemoveMessage: Hi @usershort,\n\nplease confirm that you want to delete your user account. Click the following link.
        EditRemoveTitle: Cuenta de usuario
        EditRemoveStatusDone: User account deleted. Thank you!
        EditRecoverSubject: Recuperar cuenta de usuario
        EditRecoverMessage: Hola @usershort,\n\npor favor confirma que olvidaste tu contrasenna. Haz click en el siguiente enlace.
        EditWelcomeSubject: Bienvenido
        EditWelcomeMessage: Hola @usershort,\n\ntu cuenta de usuario ha sido creada. Diviértete editando el sitio web.
        EditGoodbyeSubject: Goodbye
        EditGoodbyeMessage: Hi @usershort,\n\nyour user account has been deleted. Take care.
        EditAccountTitle: User
        EditAccountInformation: You can delete your user account anytime.
        EditAccountMore: Read more…
        EditAccountStatusNone: Here you can change your user account.
        EditAccountStatusInvalid: Please enter a valid email.
        EditAccountStatusTaken: Please enter a different email.
        EditAccountStatusWeak: Please enter a different password.
        EditAccountStatusShort: Please enter a longer password.
        EditAccountStatusNext: User account will be changed, please check your emails.
        EditQuitTitle: Delete user account
        EditQuitStatusNone: Please enter your name to confirm.
        EditQuitStatusMismatch: Please enter a different name.
        EditQuitStatusNext: User account will be deleted, please check your emails.
        EditConfigureTitle: Website
        EditConfigureSitename: Name of the website:
        EditConfigureAuthor: Name of the webmaster:
        EditConfigureEmail: Email of the webmaster:
        EditConfigureInformation: The webmaster can approve new user accounts.
        EditConfigureStatusNone: Here you can configure your website.
        EditConfigureStatusInvalid: Please enter a valid email.
        EditUpdateTitle: Updates
        EditUpdateStatusNone: Datenstrom Yellow is for people who make small websites.
        EditUpdateStatusCheck: Checking for updates…
        EditUpdateStatusUpdates: The following updates are available:
        EditUpdateStatusOk: Your website is up to date.
        EditOkButton: Ok
        EditCancelButton: Cancelar
        EditChangeButton: Cambiar
        EditCreateButton: Crear
        EditEditButton: Guardar
        EditDeleteButton: Borrar
        EditUpdateButton: Actualizar
        EditEdit: Editar página
        EditCreate: +
        EditDelete: -
        EditKeyboardLabels: Ctrl+, Alt+, Shift+, ⌘, ⌥, ⇧
        EditToolbarFormat: Format
        EditToolbarHeading: Heading
        EditToolbarH1: Heading 1
        EditToolbarH2: Heading 2
        EditToolbarH3: Heading 3
        EditToolbarParagraph: Normal text
        EditToolbarPre: Source code
        EditToolbarNotice: Notice
        EditToolbarQuote: Quote
        EditToolbarBold: Bold
        EditToolbarItalic: Italic
        EditToolbarStrikethrough: Strikethrough
        EditToolbarCode: Code
        EditToolbarList: List
        EditToolbarUl: • Unordered list
        EditToolbarOl: 1. Ordered list
        EditToolbarTl: ✓ Task list
        EditToolbarLink: Link
        EditToolbarFile: File
        EditToolbarEmojiawesome: Emoji
        EditToolbarFontawesome: Icon
        EditToolbarStatus: Status
        EditToolbarUndo: Undo
        EditToolbarRedo: Redo
        EditToolbarPreview: Preview
        EditToolbarHelp: Ayuda
        EditMailFooter: @sitename
        EditDataGenerated: Esta página se genera automáticamente.
        EditUploadProgress: Subir archivo…
        EditUserDescription: Editor
        EditMenuSettings: Configuraciones
        EditMenuHelp: Ayuda
        EditMenuLogout: Salir
        EditYellowUrl: https://datenstrom.se/yellow/
        EditYellowHelpUrl: https://datenstrom.se/yellow/help/
        EmojiawesomeDescription: Lots and lots of emoji.
        EnglishDescription: English/English with language 'en'.
        FeedDescription: Feed with recent changes.
        FontawesomeDescription: Icons and symbols.
        FrenchDescription: French/Français with language 'fr'.
        GalleryDescription: Image gallery with popup.
        GermanDescription: German/Deutsch with language 'de'.
        GooglecalendarDescription: Embed Google calendar.
        GooglemapDescription: Embed Google map.
        HelloworldDescription: Example feature for Datenstrom Yellow.
        HelpDescription: Help for your website.
        HighlightDescription: Highlight source code.
        HungarianDescription: Hungarian/Magyar with language 'hu'.
        ImageDescription: Images and thumbnails.
        ImageDefaultAlt: Image without description
        InstagramDescription: Embed Instagram photos.
        InstallTitle: Hola
        InstallLanguage: ¿Cuál es su idioma?
        InstallExtension: ¿Qué quieres hacer?
        InstallExtensionWebsite: Pequeño sitio web
        InstallExtensionBlog: Pequeño blog
        InstallExtensionWiki: Pequeño wiki
        InstallButton: Instalar
        InstallHomeTitle: Inicio
        InstallHomeText: [image photo.jpg Ejemplo rounded]\n\n[edit - Puede editar esta página en un navegador web] o utilizar un editor de texto. [Consigue ayuda](https://datenstrom.se/yellow/help/).
        InstallAboutTitle: Acerca de
        InstallAboutText: [Hecho con Datenstrom Yellow](https://datenstrom.se/yellow/).
        InstallDefaultTitle: Page
        InstallDefaultText: This is a new page.
        InstallBlogTitle: Blog page
        InstallBlogText: This is a new blog page.
        InstallWikiTitle: Wiki page
        InstallWikiText: This is a new wiki page.
        InstallExampleImage: This is an example image
        ItalianDescription: Italian/Italiano with language 'it'.
        JapaneseDescription: Japanese/日本語 with language 'ja'.
        MarkdownDescription: Text formatting for humans.
        MetaDescription: Meta data for humans and machines.
        NorwegianDescription: Norwegian/Norsk with language 'nb'.
        ParsedownDescription: Text formatting for humans.
        ParisDescription: Paris is an elegant theme.
        PolishDescription: Polish/Polski with language 'pl'.
        PortugueseDescription: Portuguese/Português with language 'pt'.
        PreviousnextDescription: Show links to previous/next page.
        PreviousnextNavigation: Page
        PreviousnextPagePrevious: ← Anterior: @title
        PreviousnextPageNext: Siguiente: @title →
        PrivateDescription: Support for password-protected pages.
        PrivatePageError: Please enter the password.
        PublishDescription: Make and publish extensions.
        RussianDescription: Russian/Русский with language 'ru'.
        SearchDescription: Full-text search.
        SearchResultsNone: Introduce un término de búsqueda.
        SearchResultsEmpty: No se encontraron resultados.
        SearchSpecialChanges: Cambios recientes
        SearchButton: Buscar
        ServeDescription: Built-in web server.
        SitemapDescription: Sitemap with all pages.
        SliderDescription: Image gallery with slider.
        SlovakDescription: Slovak/Slovenčina with language 'sk'.
        SoundcloudDescription: Embed Soundcloud audio tracks.
        SpanishDescription: Spanish/Español with language 'es'.
        StockholmDescription: Stockholm is a clean theme.
        SwedishDescription: Swedish/Svenska with language 'sv'.
        TocDescription: Table of contents.
        TrafficDescription: Create traffic analytics from log files.
        TurkishDescription: Turkish/Türkçe with language 'tr'.
        TwitterDescription: Embed Twitter messages.
        UpdateDescription: Mantenga su sitio web actualizado.
        UpdateExtensionDefaultDescription: No description available.
        UpdateExtensionDeveloper: Developed by @x.
        UpdateExtensionDesigner: Designed by @x.
        UpdateExtensionTranslator: Translated by @x.
        WikiDescription: Wiki for your website.
        WikiModified: Última actualización el
        WikiTag: Etiquetas:
        WikiSpecialPages: Todas las páginas
        WikiSpecialChanges: Cambios recientes
        YoutubeDescription: Embed Youtube videos.
END;
    }
}
